import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../utils/responsive.dart';
import '../../viewmodels/measurement_viewmodel.dart';
import '../../widgets/custom_button.dart';

class MeasurementView extends StatefulWidget {
  const MeasurementView({super.key});

  @override
  State<MeasurementView> createState() => _MeasurementViewState();
}

class _MeasurementViewState extends State<MeasurementView> {
  final _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<MeasurementViewModel>().fetchMeasurements('user1');
    });
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final gap = AppSpacing.cardGap(context);

    return Scaffold(
      appBar: AppBar(title: Text('Measurements')),
      body: Consumer<MeasurementViewModel>(
        builder: (context, viewModel, child) {
          if (_notesController.text != viewModel.notes) {
            _notesController.text = viewModel.notes;
          }

          return SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: ResponsiveCenter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildMeasurementHero(context, viewModel),
                  SizedBox(height: 18),
                  // Last Update Info
                  if (viewModel.measurement != null)
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Theme.of(
                          context,
                        ).colorScheme.primary.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: Theme.of(
                            context,
                          ).colorScheme.primary.withValues(alpha: 0.18),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.info_outline,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Last Updated',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Theme.of(
                                          context,
                                        ).colorScheme.primary,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    Text(
                                      'Updated by ${viewModel.measurement!.updatedBy}',
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    SizedBox(height: 2),
                                    Text(
                                      _formatDate(
                                        viewModel.measurement!.updatedAt,
                                      ),
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey[600],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  SizedBox(height: 24),
                  // Measurements Grid
                  Text(
                    'Body Measurements',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 16),
                  GridView.count(
                    crossAxisCount: AppSpacing.gridColumns(context),
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    childAspectRatio: MediaQuery.sizeOf(context).width < 360
                        ? 1.2
                        : 1.05,
                    crossAxisSpacing: gap,
                    mainAxisSpacing: gap,
                    children: [
                      _buildMeasurementCard(
                        'Chest',
                        viewModel.chest,
                        'cm',
                        Icons.accessibility,
                        () {
                          _showMeasurementDialog(
                            context,
                            'Chest',
                            viewModel.chest,
                            (value) => viewModel.setChest(value),
                          );
                        },
                      ),
                      _buildMeasurementCard(
                        'Waist',
                        viewModel.waist,
                        'cm',
                        Icons.accessibility,
                        () {
                          _showMeasurementDialog(
                            context,
                            'Waist',
                            viewModel.waist,
                            (value) => viewModel.setWaist(value),
                          );
                        },
                      ),
                      _buildMeasurementCard(
                        'Shoulder',
                        viewModel.shoulder,
                        'cm',
                        Icons.accessibility,
                        () {
                          _showMeasurementDialog(
                            context,
                            'Shoulder',
                            viewModel.shoulder,
                            (value) => viewModel.setShoulder(value),
                          );
                        },
                      ),
                      _buildMeasurementCard(
                        'Arms',
                        viewModel.arms,
                        'cm',
                        Icons.accessibility,
                        () {
                          _showMeasurementDialog(
                            context,
                            'Arms',
                            viewModel.arms,
                            (value) => viewModel.setArms(value),
                          );
                        },
                      ),
                      _buildMeasurementCard(
                        'Length',
                        viewModel.length,
                        'cm',
                        Icons.accessibility,
                        () {
                          _showMeasurementDialog(
                            context,
                            'Length',
                            viewModel.length,
                            (value) => viewModel.setLength(value),
                          );
                        },
                      ),
                    ],
                  ),
                  SizedBox(height: 24),
                  // Notes Section
                  Text(
                    'Additional Notes',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 12),
                  TextField(
                    maxLines: 4,
                    controller: _notesController,
                    onChanged: (value) => viewModel.setNotes(value),
                    decoration: InputDecoration(
                      hintText: 'Add any special instructions...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      contentPadding: EdgeInsets.all(12),
                    ),
                  ),
                  SizedBox(height: 18),
                  Text(
                    'Updated By',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 10),
                  SegmentedButton<String>(
                    segments: [
                      ButtonSegment(
                        value: 'Customer',
                        label: Text('Customer'),
                        icon: Icon(Icons.person_outline),
                      ),
                      ButtonSegment(
                        value: 'Tailor',
                        label: Text('Tailor'),
                        icon: Icon(Icons.design_services_outlined),
                      ),
                    ],
                    selected: {viewModel.updatedBy},
                    showSelectedIcon: false,
                    onSelectionChanged: (selection) {
                      viewModel.setUpdatedBy(selection.first);
                    },
                  ),
                  SizedBox(height: 28),
                  CustomButton(
                    text: 'Update Measurements',
                    icon: Icons.save_outlined,
                    isLoading: viewModel.isBusy,
                    onPressed: () async {
                      final messenger = ScaffoldMessenger.of(context);
                      final success = await viewModel.updateMeasurements(
                        'user1',
                        viewModel.updatedBy,
                      );
                      if (success && mounted) {
                        messenger.showSnackBar(
                          SnackBar(
                            content: Text('Measurements updated successfully'),
                            backgroundColor: Colors.green,
                          ),
                        );
                      }
                    },
                  ),
                  SizedBox(height: MediaQuery.paddingOf(context).bottom + 20),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMeasurementHero(
    BuildContext context,
    MeasurementViewModel viewModel,
  ) {
    final colorScheme = Theme.of(context).colorScheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: colorScheme.outlineVariant),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.06),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: colorScheme.secondary.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(Icons.straighten, color: colorScheme.secondary),
            ),
            SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Perfect-fit profile',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Keep sizing clear before every stitching order.',
                    style: TextStyle(
                      fontSize: 13,
                      height: 1.35,
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              '${viewModel.length.toStringAsFixed(0)} cm',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMeasurementCard(
    String label,
    double value,
    String unit,
    IconData icon,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Theme.of(context).colorScheme.outlineVariant,
          ),
          boxShadow: [
            BoxShadow(
              color: Theme.of(
                context,
              ).colorScheme.shadow.withValues(alpha: 0.05),
              blurRadius: 14,
              offset: Offset(0, 6),
            ),
          ],
        ),
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary, size: 32),
            SizedBox(height: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 8),
            Text(
              '$value',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            Text(unit, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
          ],
        ),
      ),
    );
  }

  void _showMeasurementDialog(
    BuildContext context,
    String label,
    double currentValue,
    Function(double) onSave,
  ) {
    final controller = TextEditingController(text: currentValue.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Update $label'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              hintText: 'Enter measurement in cm',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final value = double.tryParse(controller.text) ?? 0;
                onSave(value);
                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }
}
